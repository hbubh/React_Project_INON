import ActionAreaCard from "./CarCardTemplate";
import { Grid } from "@mui/material";

let carsArr = [
  {
    img: "https://hips.hearstapps.com/hmg-prod/images/2-spectre-unveiled-the-first-fully-electric-rolls-royce-front-3-4-1666037303.jpg",
    title: "Rolls Royce",
    content: "Luxury Car 2023 made in Italy",
  },
  {
    img: "https://stimg.cardekho.com/images/carexteriorimages/930x620/BMW/i7/8972/1675664292256/front-left-side-47.jpg",
    title: "BMW",
    content: "Electric Model",
  },
  {
    img: "https://www.cartoq.com/wp-content/uploads/2022/06/yellow-bent-bentley-for-sale-1.jpg",
    title: "Bentley",
    content: "Electric Model",
  },
];

const CreateCarCards = () => {
  return (
    <Grid
      container
      justifyContent={"space-around"}
      spacing={8}
      sx={{ width: "100%", padding: "30px" }}
    >
      {carsArr.map((car) => (
        <Grid item xs>
          <ActionAreaCard
            key={car.title}
            img={car.img}
            title={car.title}
            content={car.content}
          />
        </Grid>
      ))}
    </Grid>
  );
};
export default CreateCarCards;
