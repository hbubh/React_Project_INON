import CreateCarCards from "./AllCards";
import SearchAppBar from "./navBar";
import { Box } from "@mui/material";
import LabelBottomNavigation from "./bottomBar";

const Main = () => {
  return (
    <Box>
      <SearchAppBar />
      <CreateCarCards />
      <LabelBottomNavigation />
    </Box>
  );
};
export default Main;
