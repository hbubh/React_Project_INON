// import * as React from "react";
import { useState } from "react";
import Avatar from "@mui/material/Avatar";
import Button from "@mui/material/Button";
import CssBaseline from "@mui/material/CssBaseline";
import TextField from "@mui/material/TextField";
import Paper from "@mui/material/Paper";
import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import Typography from "@mui/material/Typography";
import CopyrightComponent from "./ui/CopyrightComponent";
import { useNavigate } from "react-router-dom";
import ROUTES from "../../routes/ROUTES";

const RegisterPage = () => {
  /* top lvl for hooks */
  /*   
   let emailArrState = useState("")
   emailArrState[0] -> value of current state, in our case ""
   emailArrState[1] -> function to sync dom and virtual dom
   !we never modify emailArrState[0] 
   */
  const [inputValue, setInputValue] = useState({
    Fname: "",
    Lname: "",
    email: "",
    address: "",
    password: "",
    password2: "",
  });

  const navigate = useNavigate();

  const handleRegisterSet = () => {
    setTimeout(() => {
      navigate(ROUTES.LOGIN);
    }, 2000);
  };

  const handleInputChange = (e) => {
    setInputValue((currentState) => ({
      ...currentState,
      [e.target.id]: e.target.value,
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    console.log({
      email: data.get("email"),
      password: data.get("password"),
    });
  };

  return (
    <Grid container component="main" sx={{ height: "100vh" }}>
      <CssBaseline />
      <Grid item xs={12} sm={8} md={5} component={Paper} elevation={6} square>
        <Box
          sx={{
            my: 8,
            mx: 4,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
          }}
        >
          <Avatar sx={{ m: 1, bgcolor: "navy" }}>
            <AccountCircleIcon />
          </Avatar>
          <Typography component="h1" variant="h5">
            Register
          </Typography>
          <Grid
            container
            component="form"
            noValidate
            spacing={2}
            onSubmit={handleSubmit}
            sx={{ mt: 1, padding: "30px" }}
          >
            <Grid item lg={6}>
              <TextField
                margin="normal"
                required
                fullWidth
                id="Fname"
                label="First Name"
                name="Fname"
                autoComplete="First Name"
                autoFocus
                value={inputValue.Fname}
                onChange={handleInputChange}
              />
            </Grid>
            <Grid item lg={6}>
              <TextField
                margin="normal"
                required
                fullWidth
                id="Lname"
                label="Last Name"
                name="Lname"
                autoComplete="Last Name"
                autoFocus
                value={inputValue.Lname}
                onChange={handleInputChange}
              />
            </Grid>
            <Grid item lg={6}>
              <TextField
                margin="normal"
                required
                fullWidth
                id="email"
                label="Email Address"
                name="email"
                autoComplete="email"
                autoFocus
                value={inputValue.email}
                onChange={handleInputChange}
              />
            </Grid>
            <Grid item lg={6}>
              <TextField
                margin="normal"
                required
                fullWidth
                id="address"
                label="Address"
                name="address"
                autoComplete="address"
                autoFocus
                value={inputValue.address}
                onChange={handleInputChange}
              />
            </Grid>
            <Grid item lg={6}>
              <TextField
                margin="normal"
                required
                fullWidth
                name="password"
                label="Password"
                type="password"
                id="password"
                autoComplete="current-password"
                value={inputValue.password}
                onChange={handleInputChange}
              />
            </Grid>
            <Grid item lg={6}>
              <TextField
                margin="normal"
                required
                fullWidth
                name="password2"
                label="Password Again"
                type="password"
                id="password2"
                autoComplete="current-password"
                value={inputValue.password2}
                onChange={handleInputChange}
              />
            </Grid>

            <Button
              type="submit"
              onClick={handleRegisterSet}
              fullWidth
              variant="contained"
              sx={{ mt: 3, mb: 2, bgcolor: "navy" }}
            >
              Create Account
            </Button>
            <CopyrightComponent sx={{ with: "100%", ml: "30%", mt: 1 }} />
          </Grid>
        </Box>
      </Grid>
      <Grid
        item
        xs={false}
        sm={4}
        md={7}
        sx={{
          backgroundImage: "url(https://source.unsplash.com/random?wallpapers)",
          backgroundRepeat: "no-repeat",
          backgroundColor: (t) =>
            t.palette.mode === "light"
              ? t.palette.grey[50]
              : t.palette.grey[900],
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      />
    </Grid>
  );
};

export default RegisterPage;
