import { Grid } from "@mui/material";
import TemplateFunc from "./ui/TeplateCard";
import { useState } from "react";
import nextKey from "generate-my-key"; // תוסף שלא מחייב מפתח ייחודי לכל MAP */

let dataFromServer = [
  {
    _id: "650ae1b9ae22ab105f45531d",
    img: "https://th.bing.com/th/id/OIP.r92oPkMFvIFibdEyv5PcjQAAAA?pid=ImgDet&rs=1",
    title: "Google",
    subtitle: "Bard",
    phone: "0500000000",
    add: "Natanya, Israel",
    mail: "inon@gmail.com",
  },
  {
    _id: "650ae1b9ae22ab105f45531e",
    img: "https://th.bing.com/th/id/R.b92ec72f277dcb075cb52fc1a724056e?rik=z2o3S%2fJWHEG1Gg&riu=http%3a%2f%2fileap.org%2fwp-content%2fuploads%2f2018%2f07%2fMicrosoft-300px-250x250.png&ehk=ucUhcr56rActnfKaxACi%2brtZvWBR7XGs1s5uuivOuTE%3d&risl=&pid=ImgRaw&r=0",
    title: "Microsoft",
    subtitle: "Windows 11",
    phone: "0500000000",
    add: "Beer Sheva, Israel",
    mail: "Eden@gmail.com",
  },
  {
    _id: "650ae1b9ae22ab105f45531f",
    img: "https://www.interstellarrift.com/wiki/images/thumb/d/d8/Youtube-logo-png-photo-0.png/600px-Youtube-logo-png-photo-0.png",
    title: "YouTube",
    subtitle: "Music",
    phone: "0500000000",
    add: "Herzeliya, Israel",
    mail: "Shany@gmail.com",
  },
  {
    _id: "650ae1b9ae22ab105f455320",
    img: "https://th.bing.com/th/id/OIP.8DppqmUmmFpjTZY5SqN7-AHaHa?pid=ImgDet&w=182&h=182&c=7&dpr=1.3",
    title: "Apple",
    subtitle: "Iphon 15",
    phone: "0500000000",
    add: "Tel Aviv, Israel",
    mail: "EliSheva@gmail.com",
  },
];

const NavCards = () => {
  const [newData, setNewData] = useState(dataFromServer);
  const handleDeleteCard = (_id) => {
    setNewData((currentState) =>
      currentState.filter((card) => card._id !== _id)
    );
  };
  const handleLikeCard = (_id) => {};
  const handleAddCard = (_id) => {};
  const handleEditCard = (_id) => {};
  return (
    <Grid
      container
      spacing={2}
      justifyContent={"space-around"}
      sx={{ width: "100%", padding: "30px" }}
    >
      {newData.map((card) => (
        <TemplateFunc
          key={nextKey()}
          _id={card._id}
          img={card.img}
          title={card.title}
          subtitle={card.subtitle}
          phone={card.phone}
          add={card.add}
          mail={card.mail}
          onDeleteCard={handleDeleteCard}
          onLikeCard={handleLikeCard}
          onEditCard={handleEditCard}
          onAddCard={handleAddCard}
        />
      ))}
    </Grid>
  );
};
export default NavCards;
