import UserComponent from "./PersonalUserComponent";

const InonHello = () => {
  return <UserComponent>{"Inon Genish"}</UserComponent>;
};
export default InonHello;
