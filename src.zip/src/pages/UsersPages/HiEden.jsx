import UserComponent from "./PersonalUserComponent";

const EdenHello = () => {
  return <UserComponent>{"Eden Drori"}</UserComponent>;
};
export default EdenHello;
