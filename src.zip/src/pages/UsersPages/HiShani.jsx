import UserComponent from "./PersonalUserComponent";

const ShaniHello = () => {
  return <UserComponent>{"Shani"}</UserComponent>;
};
export default ShaniHello;
