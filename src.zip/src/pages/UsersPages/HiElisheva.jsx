import UserComponent from "./PersonalUserComponent";

const ElishevaHello = () => {
  return <UserComponent>{"Elisheva Segal"}</UserComponent>;
};
export default ElishevaHello;
