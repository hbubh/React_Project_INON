import { Box } from "@mui/material";
import LayoutComponent from "./layout/LayoutComponent";
import Routes from "./routes/Router";

const App = () => {
  return (
    <Box>
      <LayoutComponent>
        <Routes />
      </LayoutComponent>
    </Box>
  );
};

export default App;
