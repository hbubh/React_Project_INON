const My3Component = () => {
  return <h3>now What?</h3>;
};

export default My3Component;
