const My2Component = () => {
  return <h2>Bye world!</h2>;
};

export default My2Component;
