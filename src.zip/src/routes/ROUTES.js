const ROUTES = {
  HOME: "/",
  REGISTER: "/register",
  LOGIN: "/login",
  EDIT: "/edit",
  CREATE: "/create",
  USERS: "/users",
  HIINON: "/users/inon",
  HIEDEN: "/users/eden",
  HISHANI: "/users/shani",
  HIELISHEVA: "/users/elishave",
};
export default ROUTES;
