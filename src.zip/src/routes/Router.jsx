import { Routes, Route } from "react-router-dom";
import ROUTES from "./ROUTES";
import NavCards from "../pages/CradSMedia/HomeCardPage";
import RegisterPage from "../pages/login/RegisterPage";
import LoginPage from "../pages/login/LoginPage";
import CreateCard from "../pages/CradSMedia/CreateComponent";
import ChangeContent from "../pages/CradSMedia/EditComponent";
import UsersFunc from "../pages/UsersPages/TirgulFilter2609";
import EdenHello from "../pages/UsersPages/HiEden";
import InonHello from "../pages/UsersPages/HiInon";
import ShaniHello from "../pages/UsersPages/HiShani";
import ElishevaHello from "../pages/UsersPages/HiElisheva";
import ErrorComponent from "../layout/main/ErrorPage";

const Router = () => {
  return (
    <Routes>
      <Route path={ROUTES.HOME} element={<NavCards />} />
      <Route path={ROUTES.REGISTER} element={<RegisterPage />} />
      <Route path={ROUTES.LOGIN} element={<LoginPage />} />
      <Route path={ROUTES.CREATE} element={<CreateCard />} />
      <Route path={ROUTES.EDIT} element={<ChangeContent />} />
      <Route path={ROUTES.USERS} element={<UsersFunc />} />
      <Route path={ROUTES.HIEDEN} element={<EdenHello />} />
      <Route path={ROUTES.HIINON} element={<InonHello />} />
      <Route path={ROUTES.HISHANI} element={<ShaniHello />} />
      <Route path={ROUTES.HIELISHEVA} element={<ElishevaHello />} />
      <Route path="*" element={<ErrorComponent />} />
    </Routes>
  );
};
export default Router;
