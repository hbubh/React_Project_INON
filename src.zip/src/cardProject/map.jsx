const arr = [
  {
    img: "https://th.bing.com/th/id/OIP.8DppqmUmmFpjTZY5SqN7-AHaHa?pid=ImgDet&w=182&h=182&c=7&dpr=1.3",
    title: "Card 1",
    subtitle: "sub Card 1 ",
    phone: "054-5544332",
    add: "my add 55",
    mail: "inonmail@mail.com",
  },
  {
    img: "https://th.bing.com/th/id/OIP.8DppqmUmmFpjTZY5SqN7-AHaHa?pid=ImgDet&w=182&h=182&c=7&dpr=1.3",
    title: "Card 2",
    subtitle: "sub Card 2 ",
    phone: "054-5544332",
    add: "my add 55",
    mail: "inonmail@mail.com",
  },
  {
    img: "https://th.bing.com/th/id/OIP.8DppqmUmmFpjTZY5SqN7-AHaHa?pid=ImgDet&w=182&h=182&c=7&dpr=1.3",
    title: "Card 3",
    subtitle: "sub Card 3 ",
    phone: "054-5544332",
    add: "my add 55",
    mail: "inonmail@mail.com",
  },
];

/*   {
    arr.map((item) => (
      <TemplateFunc
        key={nextKey()}
        title={item.title}
        subtitle={item.subtitle}
        phone={item.phone}
        add={item.add}
        mail={item.mail}
        img={item.img}
      />
    ));
  } */
