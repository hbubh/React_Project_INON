import { useState } from "react";
import MainComponent from "./main/MainComponent";
import FooterComponent from "./footer/FooterComponent";
import ResponsiveAppBar from "./header/navBar";
import { ThemeProvider, createTheme } from "@mui/material/styles";
import CssBaseline from "@mui/material/CssBaseline";

const LayoutComponent = ({ children }) => {
  /*  const [thisTheme, setTheme] = useState(false);
  const darkTheme = createTheme({
    palette: {
      mode: "dark",
    },
  });
  const lightTheme = createTheme({
    palette: {
      mode: "light",
    },
  });
  const setThemeChamge = (checked) => {
    setTheme(checked);
  }; */

  const [thisTheme, setTheme] = useState(false);

  const darkTheme = createTheme({
    palette: {
      mode: "dark",
    },
  });
  const lightTheme = createTheme({
    palette: {
      mode: "light",
    },
  });

  const setThemeChange = (checked) => {
    setTheme(checked);
  };

  return (
    <ThemeProvider theme={thisTheme ? darkTheme : lightTheme}>
      <CssBaseline />
      <ResponsiveAppBar themeChange={setThemeChange} thisTheme={thisTheme} />
      <MainComponent>{children}</MainComponent>
      {/* <MainComponent><Homepage /></MainComponent> */}
      <FooterComponent />
    </ThemeProvider>
  );
};

export default LayoutComponent;
