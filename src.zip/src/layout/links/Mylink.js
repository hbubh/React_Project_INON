import ROUTES from "../../routes/ROUTES";

const arrLinks = [
  { to: ROUTES.HOME, children: "Home" },
  { to: ROUTES.REGISTER, children: "Register" },
  { to: ROUTES.LOGIN, children: "Login" },
  { to: ROUTES.USERS, children: "Users" },
];

export default arrLinks;
