import { useState } from "react";
import arrLinks from "../links/Mylink";
import { BottomNavigation } from "@mui/material";
import FooterTamplate from "../../pages/CradSMedia/ui/FooterTamplate";
import nextKey from "generate-my-key";

const FooterComponent = () => {
  const [value, setValue] = useState(0);
  return (
    <BottomNavigation
      style={{
        backgroundColor: "darkgray",
        boxShadow: "-3px 0px 5px",
        opacity: "0.8",
        width: "100vw",
        position: "absolute",
        marginTop: "9vh",
      }}
      showLabels
      value={value}
      onChange={(newValue) => {
        setValue(newValue);
      }}
    >
      {arrLinks.map((link) => (
        <FooterTamplate to={link.to} key={nextKey()}>
          {link.children}
        </FooterTamplate>
      ))}
    </BottomNavigation>
  );
};

export default FooterComponent;
