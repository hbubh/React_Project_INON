import FavoriteIcon from "@mui/icons-material/Favorite";
import EditIcon from "@mui/icons-material/Edit";
import AddIcon from "@mui/icons-material/Add";
import DeleteSweepIcon from "@mui/icons-material/DeleteSweep";
import {
  Typography,
  IconButton,
  Card,
  CardActionArea,
  CardMedia,
  CardHeader,
  CardContent,
  Grid,
  Box,
  Divider,
} from "@mui/material";
/* import TemplateFunc from "@mui/icons-material/Google"; */

const TemplateFunc = ({
  _id,
  img,
  title,
  subtitle,
  phone,
  add,
  mail,
  onDeleteCard,
  onLikeCard,
  onEditCard,
  onAddCard,
}) => {
  const handleDeleteCardClick = () => {
    console.log("_id to delete (CardComponent)", _id);
    onDeleteCard(_id);
  };
  const handleEditCardClick = () => {
    console.log("_id to Edit (CardComponent)", _id);
    onEditCard(_id);
  };
  const handleLikeCardClick = () => {
    console.log("_id to Like (CardComponent)", _id);
    onLikeCard(_id);
  };
  const handleAddCardClick = () => {
    console.log("_id to Add (CardComponent)", _id);
    onAddCard(_id);
  };
  return (
    <Grid item xs={12} sm={6} md={4} lg={3}>
      <Card
        sx={{
          boxShadow: "2px 2px 5px",
          border: "3px solid rgb(38, 86, 243)",
          borderRadius: "8px",
        }}
      >
        <CardActionArea>
          <CardMedia
            sx={{ width: "100%", height: "auto" }}
            component="img"
            image={img}
          ></CardMedia>
          <CardHeader
            title={title}
            subheader={subtitle}
            sx={{ backgroundColor: "rgb(38, 86, 243)" }}
          />
          <CardContent sx={{ backgroundColor: "lightblue" }}>
            <Typography>
              <span style={{ fontWeight: "bold" }}>Phone: </span>
              {phone}
            </Typography>
            <Typography>
              <span style={{ fontWeight: "bold" }}>Address: </span>
              {add}
            </Typography>
            <Typography>
              <span style={{ fontWeight: "bold" }}>Mail: </span>
              {mail}
            </Typography>
          </CardContent>
          <Divider />
          <Box
            display="flex"
            justifyContent={"space-between"}
            sx={{ backgroundColor: "lightblue" }}
          >
            <Box>
              <IconButton onClick={handleLikeCardClick}>
                <FavoriteIcon />
              </IconButton>
              <IconButton onClick={handleEditCardClick}>
                <EditIcon />
              </IconButton>
            </Box>
            <Box>
              <IconButton onClick={handleAddCardClick}>
                <AddIcon />
              </IconButton>
              <IconButton onClick={handleDeleteCardClick}>
                <DeleteSweepIcon />
              </IconButton>
            </Box>
          </Box>
        </CardActionArea>
      </Card>
    </Grid>
  );
};

export default TemplateFunc;
